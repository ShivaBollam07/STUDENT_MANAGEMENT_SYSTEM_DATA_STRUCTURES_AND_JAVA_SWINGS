package com.mycompany.student_management_system;

public class Student {


}
